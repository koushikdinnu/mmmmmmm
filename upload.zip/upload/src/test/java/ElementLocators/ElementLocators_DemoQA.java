package ElementLocators;

import org.openqa.selenium.By;

public class ElementLocators_DemoQA {

public static By Registerlink=By.linkText("Register");
public static By LinkText=By.linkText("REGISTER");
public static  By FirstName= By.xpath("//input[@name='firstName']");
public static  By LastName= By.xpath("//input[@name='lastName']");
public static  By phone= By.xpath("//input[@name='phone']");
public static  By email= By.xpath("//input[@name='userName']");
public static  By address= By.xpath("//input[@name='address1']");
public static  By city= By.xpath("//input[@name='city']");
public static  By state= By.xpath("//input[@name='state']");
public static  By postalcode=By.xpath("//input[@name='postalCode']");
public static By country=By.xpath("//select[@name='country']");
public static By username=By.xpath("//input[@name='email']");
public static By password=By.xpath("//input[@name='password']");
public static By confirmpassword=By.xpath("(//input[@type='password'])[2]");
public static By submit=By.xpath("//input[@name='register']");
public static By linkText=By.xpath("//a[@href='mercurysignoff.php']");
public static By hotel=By.xpath("//a[@href='mercuryunderconst.php']");
public static By back=By.xpath("//img[@src='/images/forms/home.gif']");

//this is for webshop 
public static By Reglink=By.linkText("Register"); 
public static By Firstname=By.xpath("//input[@id='FirstName']");
public static By Lastname=By.xpath("//input[@id='LastName']");
public static By Email=By.xpath("//input[@id='Email']");
public static By Password=By.xpath("//input[@id='Password']");
public static By ConfirmPassword=By.id("ConfirmPassword");
public static By Registerbutton=By.id("register-button");
}



