package PageFactPack;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PageFactory {
static WebDriver driver;

public static void openbrowser(String url)
{
	System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
	driver= new ChromeDriver();
	driver.get(url);
	System.out.println("Browser opened");
	driver.manage().window().maximize();		
}
public static void SendValue(String val,By locator)
{
	WebElement ele=driver.findElement(locator);
	System.out.println("The text "+val +" is entered."); 
	ele.sendKeys(val);
}
public static void clickmethod(By locatorforClick) throws InterruptedException
{
	driver.findElement(locatorforClick).click();
	System.out.println(locatorforClick +" is clicked.");
	Thread.sleep(2000);	
}
public static void close()
{
	System.out.println("Closing the Browser");
	driver.close();
}
public static void select(By locator,String val)
{
	WebElement ad=driver.findElement(locator);
	Select dd=new Select(ad);
	dd.selectByVisibleText(val);
	System.out.println("The value: " +val +" is selected from the dropdown");
}
 
}
