package cucumberOptions;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
       features = "C:\\Users\\nkoushik\\Desktop\\upload\\src\\test\\java\\Features\\FeatureDemoQA.feature",
       glue= {"StepDefinitions"},
       monochrome=false,
       plugin = {"html:target/Destination"}
       )


public class TestRunner {

}
